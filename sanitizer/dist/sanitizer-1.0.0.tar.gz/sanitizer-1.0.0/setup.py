from distutils.core import setup
setup(
    name = 'sanitizer',
    version = '1.0.0',
    py_modules = ['sanitizer'],
    author = 'hfpython',
    author_email = 'hfpython@headfirstlabs.com',
    url = 'http://www.headfirstlabs.com',
    description = 'To remove - and : from a time string',
    )
