# Head first Python
# From the page 42

def printLol(theList, level=0):
    for i in theList:
        if isinstance(i, list):
            printLol(i, level+1)
        else:
            for tabStop in range(level):
                print("\t", end = '')
            print(i)
