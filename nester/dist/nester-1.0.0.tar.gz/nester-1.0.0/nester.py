# Head first Python
# From the page 42

def printLol(theList):
    for i in theList:
        if isinstance(i, list):
            printLol(i)
        else:
            print(i)
