# Head first Python
# From the page 42

def printLol(theList, indent=False, level=0):
    for i in theList:
        if isinstance(i, list):
            printLol(i, indent, level+1)
        else:
            if indent:
                for tabStop in range(level):
                    print("\t", end = '')
            print(i)
